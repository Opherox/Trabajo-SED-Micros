# Trabajo-SED-Micros

Trabajo SED Parte micropocesadores: . Grupo 14. Tutor: Luis Castedo

## **Miembros del grupo:**

| Nombre | Número de matricula |
| ------ | ------------------- |
| Fernando Moreno Santa Cruz | 56000 |
| David Pinto Llorente | 56033 |
| Miguel Ángel Pascual Collar | 55584 |


## **Descripción de tarea:**



## **Requisitos generales:**

* Utilizacion de entradas/salidas: Pulsadores, LEDs, Displays, Otros...

* Uso de interrupciones

* Uso de temporizadores

* Uso de ADC/DAC

* Uso de Git

* Funcionamiento correcto:
